<?php
 
include_once("ogs/semester_view.php");

?>