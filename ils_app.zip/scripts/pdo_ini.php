<?php

	define('FRDSN', "mysql:host=localhost;port=3306;dbname=lithefzj_engine");
	define('ILSDSN', "mysql:host=localhost;port=3306;dbname=lithefzj_library");
	//define('HRISDSN', "mysql:host=localhost;port=3306;dbname=infobahn_hris");
	define('USER', 'lithefzj_darryl');
	define('PASS', 'LeyyeL03@!');
