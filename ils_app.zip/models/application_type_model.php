<?php
Class Application_type_model extends Commonmodel
{
    
}

?>
